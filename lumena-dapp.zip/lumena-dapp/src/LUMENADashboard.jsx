import { useEffect, useState } from "react";
import { ethers } from "ethers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

const contractAddress = "0x703eCBAFC63b6C384bDbd46ae3dF75838Dd7A11a";
const abi = [
  "function createValue(address user, uint256 amount, string intent) public",
  "function transfer(address to, uint256 amount, string purpose) public",
  "function requestFiatOut(uint256 amount) public",
  "function balance(address user) view returns (uint256)"
];

export default function LUMENADashboard() {
  const [wallet, setWallet] = useState(null);
  const [contract, setContract] = useState(null);
  const [balance, setBalance] = useState("0");
  const [amount, setAmount] = useState("");
  const [intent, setIntent] = useState("");
  const [to, setTo] = useState("");
  const [purpose, setPurpose] = useState("");
  const [error, setError] = useState(null);

  useEffect(() => {
    const init = async () => {
      try {
        if (!window.ethereum) {
          setError("MetaMask is not available. Please install MetaMask.");
          return;
        }

        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const lumena = new ethers.Contract(contractAddress, abi, signer);

        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        setWallet(accounts[0]);
        setContract(lumena);
      } catch (err) {
        console.error(err);
        setError("Failed to connect to wallet.");
      }
    };
    init();
  }, []);

  const fetchBalance = async () => {
    if (!contract || !wallet) return;
    try {
      const b = await contract.balance(wallet);
      setBalance(ethers.utils.formatEther(b));
    } catch (err) {
      console.error("Failed to fetch balance:", err);
    }
  };

  useEffect(() => {
    if (wallet) fetchBalance();
  }, [wallet, contract]);

  const create = async () => {
    if (!wallet || !contract) return;
    try {
      const tx = await contract.createValue(wallet, ethers.utils.parseEther(amount), intent);
      await tx.wait();
      fetchBalance();
    } catch (err) {
      console.error("Create error:", err);
    }
  };

  const send = async () => {
    try {
      const tx = await contract.transfer(to, ethers.utils.parseEther(amount), purpose);
      await tx.wait();
      fetchBalance();
    } catch (err) {
      console.error("Send error:", err);
    }
  };

  const withdraw = async () => {
    try {
      const tx = await contract.requestFiatOut(ethers.utils.parseEther(amount));
      await tx.wait();
      fetchBalance();
    } catch (err) {
      console.error("Withdraw error:", err);
    }
  };

  return (
    <div className="p-8 max-w-xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">💠 LUMENA Bank Dashboard</h1>

      {error && <div className="text-red-500 text-center">{error}</div>}

      <Card>
        <CardContent className="p-4 space-y-2">
          <div>Wallet: {wallet}</div>
          <div>Balance: {balance} LUMENA</div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-2">
          <h2 className="font-semibold">Create Value</h2>
          <Input placeholder="Amount (e.g., 10)" value={amount} onChange={e => setAmount(e.target.value)} />
          <Input placeholder="Intent (e.g., to heal)" value={intent} onChange={e => setIntent(e.target.value)} />
          <Button onClick={create}>Create LUMENA</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-2">
          <h2 className="font-semibold">Send LUMENA</h2>
          <Input placeholder="Recipient address" value={to} onChange={e => setTo(e.target.value)} />
          <Input placeholder="Purpose" value={purpose} onChange={e => setPurpose(e.target.value)} />
          <Button onClick={send}>Send</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-2">
          <h2 className="font-semibold">Withdraw (Simulated Fiat Out)</h2>
          <Input placeholder="Amount to withdraw" value={amount} onChange={e => setAmount(e.target.value)} />
          <Button onClick={withdraw}>Withdraw</Button>
        </CardContent>
      </Card>
    </div>
  );
}
